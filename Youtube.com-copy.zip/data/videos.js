let videos = [{
  id:"15b6fc6f-327a-4ec4-896f-486349e85a3d-1111",
  title:"Talking Tech and AI with Google CEO",
  thumbnail:"Thumbs/thumbnail-1.webp",
  length:{
    minutes: 12,
    seconds: 44
  },
  views: "3.4 M views &#183; 6 months ago",
  channel: {
    name:"Marques Brownlee",
    followers:"3 Million followers",
    icon:"Pics/channel-1.jpeg",
  }
  
},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-2222",
  title: "Try Not To Laugh Challenge #9",
  thumbnail: "Thumbs/thumbnail-2.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "2.5 M views &#183; 6 months ago",
  channel: {
    name: "Markiplier.",
    followers: "1M followers",
    icon: "Pics/channel-2.jpeg",
  }

},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-3333",
  title: "Crazy Tik Toks Taken Moments Before DISASTER",
  thumbnail: "Thumbs/thumbnail-3.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "12M views · 1 year ago",
  channel: {
    name: "SSSniperWolf",
    followers: "6 Million followers",
    icon: "Pics/channel-3.jpeg",
  }

},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-4444",
  title: "The Simplest Math Problem No One Can Solve - Collatz Conjecture",
  thumbnail: "Thumbs/thumbnail-4.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "18M views · 4 months ago",
  channel: {
    name: "Veritasium",
    followers: "4 Million followers",
    icon: "Pics/channel-4.jpeg",
  }

},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-5555",
  title: "Kadane's Algorithm to Maximum Sum Subarray Problem",
  thumbnail: "Thumbs/thumbnail-5.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "519K views · 5 years ago",
  channel: {
    name: "CS Dojo",
    followers: "6 Million followers",
    icon: "Pics/channel-5.jpeg",
  }

},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-6666",
  title: "Anything You Can Fit In The Circle I’ll Pay For",
  thumbnail: "Thumbs/thumbnail-6.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "141M views · 1 year ago",
  channel: {
    name: "MrBeast",
    followers: "250 Million followers",
    icon: "Pics/channel-6.jpeg",
  }

},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-7777",
  title: "Talking Tech and AI with Google CEO",
  thumbnail: "Thumbs/thumbnail-7.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "3.4 M views &#183; 6 months ago",
  channel: {
    name: "Marques Brownlee",
    followers: "3 Million followers",
    icon: "Pics/channel-7.jpeg",
  }

},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-8888",
  title: "Talking Tech and AI with Google CEO",
  thumbnail: "Thumbs/thumbnail-8.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "3.4 M views &#183; 6 months ago",
  channel: {
    name: "Marques Brownlee",
    followers: "3 Million followers",
    icon: "Pics/channel-8.jpeg",
  }

},{
  id: "15b6fc6f-327a-4ec4-896f-486349e85a3d-9999",
  title: "Talking Tech and AI with Google CEO",
  thumbnail: "Thumbs/thumbnail-9.webp",
  length: {
    minutes: 12,
    seconds: 44
  },
  views: "3.4 M views &#183; 6 months ago",
  channel: {
    name: "Marques Brownlee",
    followers: "3 Million followers",
    icon: "Pics/channel-9.jpeg",
  }

}]